module("update")
$(function(){
	var $clone=String($("#board").html());
	test("update",function(){
		var $board=$("<div/>").load("//pandanoir.web.fc2.com/snowball/snowball.html #board",null,function(){
			loadComplete=true;
			ok(true,"html loaded")
		}).appendTo("body");
		var loadComplete=false,stopTime=true;
		ok(!loadComplete,"loadComplete is ready")
		stop();
		setTimeout(checker,10)
		function checker(){
			if(stopTime){start();stopTime=false}
			if(loadComplete){
				$board=$board.children().unwrap();
				equal($clone.replace(/	/g,""),$board.html().replace(/	/g,""),"Async");
				$board.remove()
			}else{
				setTimeout(checker,10)
			}
		}
	})
})